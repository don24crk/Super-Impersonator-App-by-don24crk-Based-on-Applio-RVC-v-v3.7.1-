@echo off
setlocal
set "PY=C:\Users\User\ultimate-rvc\.venv\Scripts\python.exe"
if not exist "%PY%" (
  echo FEHLER: Aktiver Applio-Python nicht gefunden:
  echo %PY%
  pause
  exit /b 1
)

echo [1/3] Installierte Paketpfade und Versionen:
"%PY%" -c "import sys, importlib.metadata as m, huggingface_hub; print('Python:',sys.executable); print('Hub-Version:',m.version('huggingface_hub')); print('Hub-Datei:',huggingface_hub.__file__)"
if errorlevel 1 goto :error

echo.
echo [2/3] Hugging Face Hub ohne Cache zwangsweise neu installieren...
"%PY%" -m pip install --no-cache-dir --force-reinstall "huggingface_hub>=1.0.0"
if errorlevel 1 goto :error

echo.
echo [3/3] Importtest:
"%PY%" -c "import huggingface_hub, huggingface_hub.dataclasses; print('OK:', huggingface_hub.__version__); print('Modul:', huggingface_hub.dataclasses.__file__)"
if errorlevel 1 goto :error

echo.
echo ERFOLG: huggingface_hub.dataclasses ist importierbar.
echo Bitte jetzt die Anwendung vollstaendig schliessen und neu starten.
pause
exit /b 0

:error
echo.
echo FEHLER: Reparatur oder Importtest fehlgeschlagen.
echo Bitte den gesamten Konsoleninhalt sichern.
pause
exit /b 1
