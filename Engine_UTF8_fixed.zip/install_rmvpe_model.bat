@echo off
setlocal
set "TARGET_DIR=%~dp0models\rvc\predictors"
set "TARGET=%TARGET_DIR%\rmvpe.pt"
set "URL=https://huggingface.co/IAHispano/Applio/resolve/main/Resources/predictors/rmvpe.pt"
if exist "%TARGET%" (
  for %%F in ("%TARGET%") do if %%~zF GTR 100000000 (
    echo RMVPE-Modell ist bereits vorhanden:
    echo %TARGET%
    pause
    exit /b 0
  )
)
if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"
echo Lade RMVPE-Modell herunter (ca. 181 MB)...
echo Ziel: %TARGET%
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri '%URL%' -OutFile '%TARGET%'"
if errorlevel 1 (
  echo FEHLER: Download fehlgeschlagen. Bitte Internetverbindung pruefen.
  pause
  exit /b 1
)
for %%F in ("%TARGET%") do if %%~zF LSS 100000000 (
  echo FEHLER: Die heruntergeladene Datei ist zu klein oder unvollstaendig.
  del "%TARGET%" 2>nul
  pause
  exit /b 1
)
echo Pruefe SHA-256...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$h=(Get-FileHash -Algorithm SHA256 -LiteralPath '%TARGET%').Hash.ToLower(); if ($h -ne '6d62215f4306e3ca278246188607209f09af3dc77ed4232efdd069798c4ec193') { Write-Error ('SHA-256 stimmt nicht: ' + $h); exit 1 }"
if errorlevel 1 (
  del "%TARGET%" 2>nul
  echo FEHLER: Pruefsumme stimmt nicht. Datei wurde geloescht.
  pause
  exit /b 1
)
echo ERFOLG: RMVPE wurde installiert.
echo %TARGET%
echo Bitte die App neu starten.
pause
