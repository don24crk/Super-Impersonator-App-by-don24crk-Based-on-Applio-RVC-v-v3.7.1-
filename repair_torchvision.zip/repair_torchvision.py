from __future__ import annotations

import re
import subprocess
import sys

# Official torchvision release pairs. The patch version is kept aligned where
# that release exists; for the reported torch 2.11.0 this selects 0.26.0.
TORCHVISION_MINOR_BY_TORCH = {
    (2, 0): 15,
    (2, 1): 16,
    (2, 2): 17,
    (2, 3): 18,
    (2, 4): 19,
    (2, 5): 20,
    (2, 6): 21,
    (2, 7): 22,
    (2, 8): 23,
    (2, 9): 24,
    (2, 10): 25,
    (2, 11): 26,
}


def main() -> int:
    print(f"[INFO] Verwende Python: {sys.executable}")
    try:
        import torch
    except Exception as exc:
        print(f"[FEHLER] PyTorch kann nicht importiert werden: {exc}")
        return 1

    raw_version = str(torch.__version__)
    match = re.match(r"^(\d+)\.(\d+)\.(\d+)", raw_version)
    if not match:
        print(f"[FEHLER] PyTorch-Version nicht lesbar: {raw_version}")
        return 1
    major, minor, patch = map(int, match.groups())
    pair = (major, minor)
    if pair not in TORCHVISION_MINOR_BY_TORCH:
        print(f"[FEHLER] Keine geprÃ¼fte Torchvision-Zuordnung fÃ¼r PyTorch {raw_version}.")
        print("PyTorch bleibt unverÃ¤ndert; es wurde nichts installiert.")
        return 1

    tv_minor = TORCHVISION_MINOR_BY_TORCH[pair]
    tv_patch = patch
    # The known stable pair for the reported version is exactly 2.11.0/0.26.0.
    torchvision_version = f"0.{tv_minor}.{tv_patch}"

    cuda = getattr(torch.version, "cuda", None)
    if cuda is None:
        index_url = "https://download.pytorch.org/whl/cpu"
        variant = "CPU"
    else:
        cuda_match = re.match(r"^(\d+)\.(\d+)", str(cuda))
        if not cuda_match:
            print(f"[FEHLER] CUDA-Version nicht lesbar: {cuda!r}")
            return 1
        cuda_major, cuda_minor = map(int, cuda_match.groups())
        supported_cuda_indexes = {(12, 6): "cu126", (12, 8): "cu128", (13, 0): "cu130"}
        cuda_key = (cuda_major, cuda_minor)
        if cuda_key not in supported_cuda_indexes:
            print(f"[FEHLER] Kein geprÃ¼fter Torch-Wheel-Index fÃ¼r CUDA {cuda}.")
            print("PyTorch bleibt unverÃ¤ndert. Bitte die CUDA-Variante manuell prÃ¼fen.")
            return 1
        index_url = "https://download.pytorch.org/whl/" + supported_cuda_indexes[cuda_key]
        variant = f"CUDA {cuda}"

    print(f"[INFO] Erkannte Kombination: torch {raw_version} / torchvision {torchvision_version} ({variant})")
    print("[INFO] PyTorch und Torchaudio werden NICHT geÃ¤ndert.")
    print("[INFO] Installiere nur das passende Torchvision-Wheel ...")

    install = [
        sys.executable, "-m", "pip", "install",
        "--no-cache-dir", "--force-reinstall", "--no-deps",
        f"torchvision=={torchvision_version}",
        "--index-url", index_url,
    ]
    result = subprocess.run(install, check=False)
    if result.returncode:
        print("[FEHLER] Torchvision-Installation fehlgeschlagen.")
        print("PrÃ¼fe die Internetverbindung und ob das Wheel fÃ¼r Python/Windows verfÃ¼gbar ist.")
        return result.returncode

    print("[INFO] PrÃ¼fe Import und den kompilierten torchvision::nms-Operator ...")
    test_code = (
        "import torch, torchvision; "
        "from torchvision.ops import nms; "
        "boxes=torch.tensor([[0.,0.,10.,10.],[1.,1.,9.,9.]]); "
        "scores=torch.tensor([0.9,0.8]); "
        "out=nms(boxes,scores,0.5); "
        "print('PyTorch:',torch.__version__); "
        "print('Torchvision:',torchvision.__version__); "
        "print('NMS-Ausgabe:',out.tolist())"
    )
    test = subprocess.run([sys.executable, "-c", test_code], check=False)
    if test.returncode:
        print("[FEHLER] Import-/NMS-Test fehlgeschlagen. Bitte den gesamten Fehlertext senden.")
        return test.returncode

    print("[ERFOLG] Torchvision ist installiert; torchvision::nms funktioniert.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
