@echo off
setlocal
cd /d "%~dp0"

rem The app may use either a portable env\python.exe or a standard venv.
set "PYTHON=%~dp0python.exe"
if not exist "%PYTHON%" set "PYTHON=%~dp0env\python.exe"

if not exist "%PYTHON%" (
  echo [FEHLER] Python-Umgebung nicht gefunden.
  echo Gepruefte Pfade:
  echo   %~dp0python.exe
  echo   %~dp0env\python.exe
  pause
  exit /b 1
)

echo Repariere Torchvision mit:
echo "%PYTHON%"
echo.
"%PYTHON%" "%~dp0repair_torchvision.py"
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo [ERFOLG] Reparatur und NMS-Test abgeschlossen.
  echo Bitte Super Impersonator vollstaendig schliessen und neu starten.
) else (
  echo [FEHLER] Reparatur fehlgeschlagen. Bitte den Fehlertext oben kopieren.
)
pause
exit /b %RC%
